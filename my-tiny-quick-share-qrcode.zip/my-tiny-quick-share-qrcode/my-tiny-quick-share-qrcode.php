<?php
/**
 * Plugin Name: My Tiny Quick Share QRCode
 * Description: Quickly generate and share a QR code for any post from the admin list view.
 * Version:           1.0.0
 * Author:            Tonny
 * Text Domain:       my-tiny-quick-share-qrcode
 * Domain Path:       /languages
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MTQSQ_Admin {

    public function __construct() {
        // Init hooks
        add_filter( 'post_row_actions', array( $this, 'add_row_action' ), 10, 2 );
        add_filter( 'page_row_actions', array( $this, 'add_row_action' ), 10, 2 ); // Support pages too
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_footer', array( $this, 'render_modal' ) );
    }

    /**
     * Add "QR Code" link to row actions
     */
    public function add_row_action( $actions, $post ) {
        // Use shortlink (?p=123) for cleaner QR codes
        $shortlink = wp_get_shortlink( $post->ID );
        
        /* translators: %s: Post title */
        $label = sprintf( esc_html__( 'Generate QR Code for %s', 'my-tiny-quick-share-qrcode' ), $post->post_title );
        
        $actions['mtqsq_qr'] = sprintf(
            '<a href="#" class="mtqsq-trigger" data-link="%s" aria-label="%s">%s</a>',
            esc_url( $shortlink ),
            esc_attr( $label ),
            esc_html__( 'QR Code', 'my-tiny-quick-share-qrcode' )
        );

        return $actions;
    }

    /**
     * Enqueue JS/CSS only on edit.php
     */
    public function enqueue_assets( $hook ) {
        if ( 'edit.php' !== $hook ) {
            return;
        }

        wp_enqueue_style( 
            'mtqsq-admin-css', 
            plugin_dir_url( __FILE__ ) . 'assets/css/admin.css', 
            array(), 
            '1.0.0' 
        );

        wp_enqueue_script( 
            'qrcode-js', 
            plugin_dir_url( __FILE__ ) . 'assets/js/qrcode.min.js', 
            array(), 
            '1.0.0', 
            true 
        );

        wp_enqueue_script( 
            'mtqsq-admin-js', 
            plugin_dir_url( __FILE__ ) . 'assets/js/admin.js', 
            array( 'jquery', 'qrcode-js' ), 
            '1.0.0', 
            true 
        );
    }

    /**
     * Render the Modal HTML in footer
     */
    public function render_modal() {
        $screen = get_current_screen();
        if ( ! $screen || 'edit' !== $screen->base ) {
            return;
        }
        ?>
        <div id="mtqsq-modal-overlay" style="display:none;">
            <div id="mtqsq-modal">
                <div class="mtqsq-header">
                    <h3><?php esc_html_e( 'Quick Share QR Code', 'my-tiny-quick-share-qrcode' ); ?></h3>
                    <button type="button" class="mtqsq-close">&times;</button>
                </div>
                <div class="mtqsq-body">
                    <div id="mtqsq-qrcode-canvas"></div>
                    <p class="mtqsq-link-preview"></p>
                    <button type="button" class="button button-primary mtqsq-copy-btn">
                        <?php esc_html_e( 'Copy Link', 'my-tiny-quick-share-qrcode' ); ?>
                    </button>
                    <span class="mtqsq-copied-msg" style="display:none; color:#00a32a; margin-left:10px;">
                        <?php esc_html_e( 'Copied!', 'my-tiny-quick-share-qrcode' ); ?>
                    </span>
                </div>
            </div>
        </div>
        <?php
    }
}

new MTQSQ_Admin();
