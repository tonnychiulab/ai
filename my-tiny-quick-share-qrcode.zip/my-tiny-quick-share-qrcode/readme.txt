=== My Tiny Quick Share QRCode ===
Contributors: My Tiny Series
Tags: qrcode, share, quick, admin
Requires at least: 5.8
Tested up to: 6.4
Stable Tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Quickly generate and share a QR code for any post from the admin list view.

== Description ==

My Tiny Quick Share QRCode adds a simple "QR Code" link to the row actions in your "All Posts" list. Clicking it instantly opens a modal with a QR code for that post's shortlink, perfect for quickly testing URLs on mobile devices or sharing with others.

Features:
*   **Lightweight**: Uses a tiny JavaScript library, no external API calls.
*   **Fast**: Zero database bloat, assets only load on the post list screen.
*   **Privacy Focused**: All QR generation happens locally in your browser.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Posts > All Posts and look for the "QR Code" link.

== Changelog ==

= 1.0.0 =
*   Initial release.
