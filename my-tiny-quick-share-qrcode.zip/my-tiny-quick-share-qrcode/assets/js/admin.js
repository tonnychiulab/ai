jQuery(document).ready(function ($) {
    var $modal = $('#mtqsq-modal-overlay');
    var $qrcodeContainer = $('#mtqsq-qrcode-canvas');
    var $linkPreview = $('.mtqsq-link-preview');
    var currentLink = '';

    // Open Modal
    $(document).on('click', '.mtqsq-trigger', function (e) {
        e.preventDefault();
        currentLink = $(this).data('link');

        // Clear previous
        $qrcodeContainer.empty();
        $('.mtqsq-copied-msg').hide();

        // Generate QR
        new QRCode(document.getElementById("mtqsq-qrcode-canvas"), {
            text: currentLink,
            width: 180,
            height: 180,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });

        // Set text
        $linkPreview.text(currentLink);

        // Show
        $modal.fadeIn(200);
    });

    // Close Modal
    $('.mtqsq-close, #mtqsq-modal-overlay').on('click', function (e) {
        if (e.target === this) {
            $modal.fadeOut(200);
        }
    });

    // Copy Link
    $('.mtqsq-copy-btn').on('click', function () {
        if (!currentLink) return;

        navigator.clipboard.writeText(currentLink).then(function () {
            $('.mtqsq-copied-msg').fadeIn().delay(2000).fadeOut();
        }, function (err) {
            console.error('Could not copy text: ', err);
        });
    });
});
