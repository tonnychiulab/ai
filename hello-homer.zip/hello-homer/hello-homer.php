<?php
/**
 * Plugin Name: Hello Homer
 * Plugin URI: https://github.com/yourusername/hello-homer
 * Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Homer Simpson: D'oh!
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: hello-homer
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Main plugin class
 */
class Hello_Homer {
    /**
     * Initialize the plugin
     */
    public function __construct() {
        add_action('admin_notices', array($this, 'display_homer_quote'));
        add_action('admin_head', array($this, 'add_css'));
        add_action('admin_init', array($this, 'schedule_quote_update'));
        add_action('hello_homer_update_quotes', array($this, 'update_quotes'));
    }

    /**
     * Schedule daily quote updates
     */
    public function schedule_quote_update() {
        if (!wp_next_scheduled('hello_homer_update_quotes')) {
            wp_schedule_event(time(), 'daily', 'hello_homer_update_quotes');
        }
    }

    /**
     * Fetch quotes from Frinkiac API
     *
     * @return array|false Array of quotes or false on failure
     */
    private function fetch_frinkiac_quotes() {
        $api_url = 'https://frinkiac.com/api/search?q=homer';
        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data) || !isset($data['Frame'])) {
            return false;
        }

        $quotes = array();
        foreach ($data['Frame'] as $frame) {
            if (isset($frame['Quote'])) {
                $quotes[] = $frame['Quote'];
            }
        }

        return $quotes;
    }

    /**
     * Update stored quotes
     */
    public function update_quotes() {
        $quotes = $this->fetch_frinkiac_quotes();
        if ($quotes) {
            update_option('hello_homer_quotes', $quotes);
        }
    }

    /**
     * Get a random Simpsons quote
     *
     * @return string The quote
     */
    public function get_homer_quote() {
        $quotes = get_option('hello_homer_quotes');

        // If no quotes are stored, fetch them
        if (empty($quotes)) {
            $quotes = $this->fetch_frinkiac_quotes();
            if ($quotes) {
                update_option('hello_homer_quotes', $quotes);
            } else {
                // Fallback quotes if API fails
                $quotes = array(
                    "D'oh!",
                    "Mmm... donuts.",
                    "Everything's coming up Milhouse!",
                    "I am so smart! I am so smart! S-M-R-T... I mean S-M-A-R-T!",
                    "To start press any key. Where's the ANY key?",
                    "I used to be with 'it', but then they changed what 'it' was.",
                    "I'm not a state! I'm a monster!",
                    "I'm helping!"
                );
            }
        }

        return wptexturize($quotes[array_rand($quotes)]);
    }

    /**
     * Display the quote in the admin area
     */
    public function display_homer_quote() {
        $quote = $this->get_homer_quote();
        echo '<p id="homer-quote">' . esc_html($quote) . '</p>';
    }

    /**
     * Add CSS to the admin area
     */
    public function add_css() {
        echo "
        <style type='text/css'>
        #homer-quote {
            float: right;
            padding: 5px 10px;
            margin: 0;
            font-size: 12px;
            line-height: 1.6666;
            background: #fff;
            border-left: 4px solid #ffd700;
            box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        }
        .rtl #homer-quote {
            float: left;
        }
        </style>
        ";
    }
}

// Initialize the plugin
new Hello_Homer();

// Activation hook
register_activation_hook(__FILE__, array('Hello_Homer', 'schedule_quote_update'));

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('hello_homer_update_quotes');
}); 