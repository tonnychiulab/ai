<?php
/**
 * Plugin Name: Everything WP Tutorial
 * Description: A "National Geographic" style interactive tutorial for the Everything WP development toolkit.
 * Version: 1.0.0
 * Author: Antigravity
 * Author URI: https://oberonlai.blog/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Everything_WP_Tutorial {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function add_plugin_page() {
		add_menu_page(
			'Everything WP',
			'Everything WP',
			'manage_options',
			'everything-wp-tutorial',
			array( $this, 'create_admin_page' ),
			'dashicons-superhero',
			6
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_everything-wp-tutorial' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'everything-wp-style',
			plugin_dir_url( __FILE__ ) . 'assets/css/admin-style.css',
			array(),
			'1.0.0'
		);

		wp_enqueue_script(
			'everything-wp-script',
			plugin_dir_url( __FILE__ ) . 'assets/js/admin-script.js',
			array( 'jquery' ),
			'1.0.0',
			true
		);
	}

	public function create_admin_page() {
		?>
		<div class="wrap everything-wp-wrap">
			<div class="ewp-header">
				<div class="ewp-brand">EVERYTHING WP</div>
				<nav class="ewp-nav">
					<a href="#" class="ewp-tab-link active" data-tab="tab-vision">THE VISION</a>
					<a href="#" class="ewp-tab-link" data-tab="tab-equipment">THE EQUIPMENT</a>
					<a href="#" class="ewp-tab-link" data-tab="tab-expedition">THE EXPEDITION</a>
					<a href="#" class="ewp-tab-link" data-tab="tab-pioneer">THE PIONEER</a>
				</nav>
			</div>

			<div class="ewp-content">
				<!-- Tab 1: Vision -->
				<div id="tab-vision" class="ewp-tab-content active">
					<div class="ewp-hero">
						<div class="ewp-hero-overlay">
							<h1>打造 WordPress 開發組合技</h1>
							<p class="ewp-hero-subtitle">Exploring the depths of Modular AI Development</p>
						</div>
					</div>
					<div class="ewp-section">
						<h2>模組化 AI 工具 (Modular AI Tools)</h2>
						<p>在梳理工作流程後，我們針對每個工作項目設計對應的 AI 工具。這是一場關於效率與精準度的探索。</p>
						<p>透過 <strong>Everything WP</strong>，我們整合了 Agents、Commands、Rules 與 Skills，讓 AI 成為真正的開發協作者。</p>
					</div>
				</div>

				<!-- Tab 2: Equipment -->
				<div id="tab-equipment" class="ewp-tab-content">
					<div class="ewp-section">
						<h2>裝備準備 (Preparation)</h2>
						<p>在開始探險之前，你必須準備好你的裝備。請依照以下步驟設定你的開發環境。</p>
						
						<div class="ewp-step">
							<h3>1. 複製儲存庫 (Clone Repository)</h3>
							<code class="ewp-code">git clone https://github.com/oberonlai/everything-wp.git</code>
							<p>包含四個核心資料夾：<strong>Agents, Commands, Rules, Skills</strong>。</p>
						</div>

						<div class="ewp-step">
							<h3>2. 初始化結構 (Structure)</h3>
							<p>在你的外掛根目錄建立對應的 AI 設定資料夾：</p>
							<ul class="ewp-list">
								<li>Claude Code: <code>.claude</code></li>
								<li>Cursor: <code>.cursor</code></li>
							</ul>
							<p>將下載的工具放入其中，確保 AI 能在專案範圍內讀取。</p>
						</div>
					</div>
				</div>

				<!-- Tab 3: Expedition -->
				<div id="tab-expedition" class="ewp-tab-content">
					<div class="ewp-section">
						<h2>探險指令 (Expedition Commands)</h2>
						<p>使用以下指令來導航你的開發旅程。</p>
						
						<div class="ewp-grid">
							<div class="ewp-card">
								<h3>/init-plugin</h3>
								<p>初始化外掛開發環境，包含測試套件、GitHub Actions。</p>
							</div>
							<div class="ewp-card">
								<h3>/custom-table</h3>
								<p>產生自訂資料表與對應 CRUD 類別。</p>
							</div>
							<div class="ewp-card">
								<h3>/rest-api</h3>
								<p>建立安全的 REST API Controller。</p>
							</div>
							<div class="ewp-card">
								<h3>/wp-ajax</h3>
								<p>產生 AJAX 處理器，內建 Nonce 驗證。</p>
							</div>
							<div class="ewp-card">
								<h3>/verify</h3>
								<p>執行所有品質檢查 (PHPStan, PHPUnit, PHPCS)。</p>
							</div>
							<div class="ewp-card">
								<h3>/submit-review</h3>
								<p>依照 WordPress.org 規範進行上架前檢查。</p>
							</div>
						</div>
					</div>
				</div>

				<!-- Tab 4: Pioneer -->
				<div id="tab-pioneer" class="ewp-tab-content">
					<div class="ewp-profile">
						<div class="ewp-profile-text">
							<h2>Oberon Lai</h2>
							<p class="ewp-title">Web Developer & Writer</p>
							<p>這套工具的創造者，致力於優化 WordPress 開發流程。透過 AI 與模組化思維，將繁瑣的任務自動化，讓開發者專注於創造價值。</p>
							<a href="https://oberonlai.blog/everything-wp/" target="_blank" class="ewp-btn">Visit Website</a>
						</div>
					</div>
				</div>
			</div>
			
			<div class="ewp-footer">
				<p>Everything WP Tutorial | Tribute by Antigravity</p>
			</div>
		</div>
		<?php
	}
}

new Everything_WP_Tutorial();
