jQuery(document).ready(function($) {
    // Tab Switching Logic
    $('.ewp-tab-link').on('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links and content
        $('.ewp-tab-link').removeClass('active');
        $('.ewp-tab-content').removeClass('active');
        
        // Add active class to clicked link
        $(this).addClass('active');
        
        // Show corresponding tab content
        var tabId = $(this).data('tab');
        $('#' + tabId).addClass('active');
    });
});
