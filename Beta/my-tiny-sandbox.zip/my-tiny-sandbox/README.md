# My Tiny Sandbox

**My Tiny Sandbox** allows you to instantly create lightweight, disposable WordPress environments within your existing WordPress installation. Ideal for plugin testing, theme development, or educational demos without affecting your main site.

![Screenshot](assets/screenshot.png)

## ⚡ Features

- **Instant Provisioning**: Create a fresh WordPress instance in seconds.
- **Isolated Environment**: Uses separate database table prefixes (`sb_xxxx_`) and directory structures (`sandboxes/`) to ensure isolation from the production site.
- **Magic Login**: One-click administrative access to any sandbox via secure ephemeral links.
- **Lifecycle Management**: Optional **24-hour auto-expiry** policy to automatically clean up abandoned sandboxes.
- **Resource Monitoring**: Real-time tracking of Disk Usage and Database Size for each sandbox.
- **Developer Friendly**:
  - **Copy URL**: One-click copy for sharing sandbox links.
  - **RWD Optimized**: Interface works perfectly on mobile for quick checks.
  - **Auto-Initialization**: Friendly background setup process.

## 🛠️ How It Works

My Tiny Sandbox functions as a "Virtualization" layer on top of your current stack:

1.  **File System**: It copies the minimal necessary WP core files to a dedicated `sandboxes/` directory in your site root.
2.  **Database**: It creates a new set of tables using a unique prefix (e.g., `sb_a1b2_users`) within your existing database.
3.  **Config**: It generates a custom `wp-config.php` for each sandbox, ensuring they connect to their own isolated tables.

## 📦 Installation

1.  Download the latest release zip file.
2.  Go to **Plugins > Add New > Upload Plugin**.
3.  Activate **My Tiny Sandbox**.
4.  Navigate to the "My Tiny Sandbox" admin menu to start creating sites.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📝 License

This project is licensed under the GPLv2 License.
