<div class="wrap mts-wrap">
    <h1 class="wp-heading-inline"><?php \esc_html_e('My Tiny Sandbox', 'my-tiny-sandbox'); ?></h1>

    <div class="mts-header-actions">
        <!-- Medical / Diagnostics Button -->
        <button id="mts-diagnose-btn" class="mts-header-btn secondary tooltip" data-tooltip="<?php \esc_attr_e('檢查檔案與資料庫健康度', 'my-tiny-sandbox'); ?>">
            <span class="dashicons dashicons-heart"></span>
            <?php \esc_html_e('系統診斷', 'my-tiny-sandbox'); ?>
        </button>

        <!-- Create Button -->
        <button id="create-sandbox-btn" class="mts-header-btn primary">
            <span class="dashicons dashicons-plus-alt2"></span>
            <?php \esc_html_e('建立新沙箱', 'my-tiny-sandbox'); ?>
        </button>
    </div>

    <label style="margin-left: 10px; font-weight: normal; vertical-align: baseline;">
        <input type="checkbox" id="mts-auto-expiry" value="1">
        <?php \esc_html_e('24小時後自動刪除', 'my-tiny-sandbox'); ?>
    </label>

    <!-- Secondary Actions -->
    <a href="#" target="_blank" class="page-title-action secondary" title="<?php \esc_attr_e('Coming Soon', 'my-tiny-sandbox'); ?>">
        <span class="dashicons dashicons-welcome-learn-more"></span> <?php \esc_html_e('外掛使用教學', 'my-tiny-sandbox'); ?>
    </a>
    <a href="#" target="_blank" class="page-title-action secondary" title="<?php \esc_attr_e('Coming Soon', 'my-tiny-sandbox'); ?>">
        <span class="dashicons dashicons-heart"></span> <?php \esc_html_e('贊助作者', 'my-tiny-sandbox'); ?>
    </a>

    <hr class="wp-header-end">

    <div id="sandbox-message-container"></div>

    <div class="mts-filter-tabs" style="margin: 20px 0;">
        <ul class="subsubsub">
            <li class="all"><a href="#" class="current" data-tab="active"><?php \esc_html_e('全部', 'my-tiny-sandbox'); ?> <span class="count">(<?php echo \count($sandboxes); ?>)</span></a> |</li>
            <li class="trash"><a href="#" data-tab="trash"><?php \esc_html_e('回收桶', 'my-tiny-sandbox'); ?> <span class="count" id="mts-trash-count">...</span></a></li>
        </ul>
        <br class="clear">
    </div>

    <!-- Active Grid -->
    <div id="sandbox-grid-active" class="sandbox-grid">
        <?php
        if (empty($sandboxes)) {
            echo '<div class="no-sandbox-notice">' . \esc_html__('目前沒有站點。', 'my-tiny-sandbox') . '</div>';
        } else {
            foreach ($sandboxes as $index => $sandbox) {
                // $this refers to MyTinySandbox\Admin instance if included from there
                $this->render_card($sandbox, $index);
            }
        }
        ?>
    </div>

    <!-- Trash Grid (Hidden by default) -->
    <div id="sandbox-grid-trash" class="sandbox-grid" style="display: none;">
        <!-- Orphan Alert will be injected here via JS -->
        <div id="mts-orphan-alert" class="notice notice-warning inline" style="display: none; margin-bottom: 20px;">
            <p>
                <strong>⚠️ <?php \esc_html_e('發現遺失的沙箱', 'my-tiny-sandbox'); ?></strong>
                <br>
                <?php \esc_html_e('系統在資料夾中發現了未被記錄的沙箱資料 (可能是因這前的錯誤導致)。', 'my-tiny-sandbox'); ?>
                <button id="mts-import-orphans-btn" class="button button-small"><?php \esc_html_e('立即還原至回收桶', 'my-tiny-sandbox'); ?></button>
            </p>
            <div id="mts-orphan-list" style="margin-top: 10px; font-size: 12px; color: #666;"></div>
        </div>

        <div class="trash-list-container">
            <?php
            if (empty($trash)) {
                echo '<p class="description" style="padding: 20px;">' . \esc_html__('回收桶是空的。', 'my-tiny-sandbox') . '</p>';
            } else {
                foreach ($trash as $index => $sandbox) {
                    $this->render_card($sandbox, $index, 'trash');
                }
            }
            ?>
        </div>
    </div>

    <!-- Debug Log Area -->
    <div id="mts-debug-log-container" style="margin-top: 30px; display: none;">
        <h3><?php \esc_html_e('Debug Log', 'my-tiny-sandbox'); ?></h3>
        <textarea id="mts-debug-log" class="large-text code" rows="10" readonly style="background: #f0f0f1; font-family: monospace;"></textarea>
    </div>
    <!-- Version Info -->
    <div class="sandbox-footer" style="text-align: right; margin-top: 20px; color: #a7aaad; font-size: 12px;">
        My Tiny Sandbox v<?php echo \esc_html(\MTS_VERSION); ?>
    </div>
    <!-- Confirm Delete Modal -->
    <div id="mts-confirm-modal" class="mts-modal-overlay" style="display: none;">
        <div class="mts-modal">
            <div class="mts-modal-header">
                <h3><?php \esc_html_e('⚠️ 確認刪除沙箱', 'my-tiny-sandbox'); ?></h3>
                <span class="dashicons dashicons-no-alt close-modal"></span>
            </div>
            <div class="mts-modal-body">
                <p><?php \esc_html_e('您確定要永久刪除此沙箱嗎？此動作無法復原。', 'my-tiny-sandbox'); ?></p>
                <p><strong><?php \esc_html_e('目標沙箱:', 'my-tiny-sandbox'); ?></strong> <span id="mts-modal-sandbox-name"></span></p>

                <div class="mts-warning-box">
                    <h4><?php \esc_html_e('即將刪除:', 'my-tiny-sandbox'); ?></h4>
                    <ul>
                        <li>
                            <span class="dashicons dashicons-database"></span>
                            <strong><?php \esc_html_e('資料庫:', 'my-tiny-sandbox'); ?></strong>
                            <span id="mts-modal-table-count">0</span> <?php \esc_html_e('個資料表', 'my-tiny-sandbox'); ?>
                            <div id="mts-modal-table-list" style="max-height: 100px; overflow-y: auto; font-size: 11px; background: #fff; padding: 5px; border: 1px solid #ddd; margin-top: 5px; display: none;"></div>
                            <a href="#" id="mts-toggle-table-list" style="font-size: 11px;"><?php \esc_html_e('顯示詳細列表', 'my-tiny-sandbox'); ?></a>
                        </li>
                        <li>
                            <span class="dashicons dashicons-media-default"></span>
                            <strong><?php \esc_html_e('檔案系統:', 'my-tiny-sandbox'); ?></strong>
                            <br>
                            <code id="mts-modal-file-path" style="word-break: break-all; font-size: 11px; color: #666;"></code>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="mts-modal-footer">
                <button class="button button-secondary close-modal"><?php \esc_html_e('取消', 'my-tiny-sandbox'); ?></button>
                <button id="mts-confirm-delete-btn" class="button button-primary button-hero delete-btn-danger">
                    <?php \esc_html_e('確認永久刪除', 'my-tiny-sandbox'); ?>
                </button>
            </div>
        </div>
    </div>
</div>