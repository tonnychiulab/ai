<?php

/**
 * Plugin Name: My Tiny Sandbox - Magic Login
 * Plugin URI:  https://github.com/tonny/my-tiny-sandbox
 * Description: Enables secure, one-click login from the dashboard.
 * Version: 1.0.0
 * Author: My Tiny Sandbox
 * Author URI:  https://example.com
 */

if (!defined('ABSPATH')) exit;

add_action('init', function () {
    // 1. Check if Magic Login parameters are present
    if (empty($_GET['mts_action']) || $_GET['mts_action'] !== 'magic_login') {
        return;
    }

    // 2. Check for Secret Key
    if (!defined('MTS_MAGIC_SECRET')) {
        wp_die('Magic Login Error: MTS_MAGIC_SECRET not defined.');
    }

    $timestamp = isset($_GET['ts']) ? intval($_GET['ts']) : 0;
    $signature = isset($_GET['sig']) ? $_GET['sig'] : '';

    // 3. Verify Timestamp (TTL: 5 minutes)
    if (time() - $timestamp > 300) {
        wp_die('Magic Login Error: Link expired.');
    }

    // 4. Verify Signature
    // Signature = hash_hmac('sha256', timestamp, secret)
    $expected_sig = hash_hmac('sha256', (string)$timestamp, MTS_MAGIC_SECRET);

    if (!hash_equals($expected_sig, $signature)) {
        wp_die('Magic Login Error: Invalid signature.');
    }

    // 5. Intelligent User Detection (Inspired by InstaWP)
    $user = get_user_by('login', 'admin');

    // Fallback: If 'admin' is missing, find ANY administrator
    if (!$user) {
        $admin_users = get_users(['role' => 'administrator', 'number' => 1]);
        $user = !empty($admin_users) ? $admin_users[0] : false;
    }

    // Emergency Creation: If still no user, create one
    if (!$user) {
        if (!function_exists('wp_create_user')) {
            require_once ABSPATH . 'wp-includes/registration.php';
        }
        $random_password = wp_generate_password(12, false);
        $user_id = wp_create_user('admin', $random_password, 'admin@example.com');
        $user = get_user_by('id', $user_id);
    }

    if ($user) {
        // [SELF-HEALING]
        // 1. Ensure the Role Definition exists (Fixes missing wp_user_roles option)
        $role_obj = get_role('administrator');
        if (empty($role_obj) || !$role_obj->has_cap('manage_options')) {
            if (! function_exists('populate_roles')) {
                require_once ABSPATH . 'wp-admin/includes/schema.php';
            }
            populate_roles(); // Restores default roles to wp_options
        }

        // 2. Ensure User has the Role (Fixes user capabilities meta)
        if (! in_array('administrator', (array) $user->roles)) {
            $user->add_role('administrator');

            // Force DB update for meta keys
            global $wpdb;
            $cap_key = $wpdb->prefix . 'capabilities';
            update_user_meta($user->ID, $cap_key, ['administrator' => true]);
            update_user_meta($user->ID, $wpdb->prefix . 'user_level', 10);

            clean_user_cache($user->ID);
        }

        // Login Process
        wp_clear_auth_cookie();
        wp_set_current_user($user->ID, $user->user_login);
        wp_set_auth_cookie($user->ID);

        // Crucial: Fire the standard login hook
        do_action('wp_login', $user->user_login, $user);

        // Redirect to admin dashboard
        $redirect_to = admin_url('index.php');
        wp_safe_redirect($redirect_to);
        exit;
    } else {
        wp_die('Magic Login Error: Could not find or create an administrator user.');
    }
});
