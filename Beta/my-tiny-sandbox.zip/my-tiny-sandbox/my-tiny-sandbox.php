<?php

/**
 * Plugin Name: My Tiny Sandbox
 * Plugin URI:  https://github.com/tonny/my-tiny-sandbox
 * Description: Quickly create independent, disposable WordPress environments with shared resources.
 * Version:     2.1.2
 * Author:      Senior WP Developer
 * Author URI:  https://example.com
 * Text Domain: my-tiny-sandbox
 */

if (! defined('ABSPATH')) {
    exit;
}

// Define Constants
define('MTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MTS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MTS_VERSION', '2.1.2');

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'MyTinySandbox\\';
    $base_dir = __DIR__ . '/includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    // Convert CamelCase to hyphenated (e.g., AjaxHandler -> ajax-handler)
    $filename = strtolower(preg_replace('/([a-z])([A-Z])/', '$1-$2', $relative_class));
    $filename = str_replace('_', '-', $filename);

    $file = $base_dir . 'class-' . $filename . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Activation Hook: Schedule Cron
register_activation_hook(__FILE__, function () {
    if (! wp_next_scheduled('mts_cleanup_cron')) {
        wp_schedule_event(time(), 'hourly', 'mts_cleanup_cron');
    }
});

// Deactivation Hook: Clear Cron
register_deactivation_hook(__FILE__, function () {
    $timestamp = wp_next_scheduled('mts_cleanup_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'mts_cleanup_cron');
    }
});

// Hook Cron Action
add_action('mts_cleanup_cron', ['MyTinySandbox\\SandboxService', 'scheduled_cleanup']);

function my_tiny_sandbox_init()
{
    MyTinySandbox\Main::get_instance();
}
add_action('plugins_loaded', 'my_tiny_sandbox_init');
