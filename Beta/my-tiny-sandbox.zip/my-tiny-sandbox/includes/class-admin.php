<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

class Admin
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        \add_action('admin_menu', [$this, 'add_plugin_menu']);
        \add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        \add_action('admin_bar_menu', [$this, 'add_toolbar_items'], 100);
    }

    public function add_plugin_menu()
    {
        \add_menu_page(
            'My Tiny Sandbox',
            'My Tiny Sandbox',
            'manage_options',
            'my-tiny-sandbox',
            [$this, 'render_admin_page'],
            'dashicons-layout',
            60
        );
    }

    /**
     * Add sandbox switcher to Admin Bar
     *
     * @param \WP_Admin_Bar $wp_admin_bar
     */
    public function add_toolbar_items($wp_admin_bar)
    {
        if (! \current_user_can('manage_options')) {
            return;
        }

        // Parent Node
        $wp_admin_bar->add_node([
            'id'    => 'mts_toolbox',
            'title' => '<span class="ab-icon dashicons dashicons-layout"></span> My Tiny Sandbox',
            'href'  => \admin_url('admin.php?page=my-tiny-sandbox'),
            'meta'  => ['title' => 'My Tiny Sandbox'],
        ]);

        // Get Sandboxes
        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);

        if (! \is_array($sandboxes) || empty($sandboxes)) {
            return;
        }

        foreach ($sandboxes as $sandbox) {
            $name = $sandbox['name'] ?? 'Untitled';
            $id   = $sandbox['id'];

            // Build Magic Login Link
            $href = '#';
            if (! empty($sandbox['magic_secret']) && ! empty($sandbox['url'])) {
                $timestamp = \time();
                $signature = \hash_hmac('sha256', (string)$timestamp, $sandbox['magic_secret']);
                $target_url = \untrailingslashit($sandbox['url']) . '/';
                $href = $target_url . '?mts_action=magic_login&ts=' . $timestamp . '&sig=' . $signature;
            }

            $wp_admin_bar->add_node([
                'id'     => 'mts_sb_' . $id,
                'parent' => 'mts_toolbox',
                'title'  => $name,
                'href'   => $href,
                'meta'   => [
                    'target' => '_blank',
                    'title'  => "Magic Login to $name"
                ]
            ]);
        }
    }

    public function enqueue_assets($hook)
    {
        if ('toplevel_page_my-tiny-sandbox' !== $hook) {
            return;
        }

        \wp_enqueue_style(
            'my-tiny-sandbox-css',
            \MTS_PLUGIN_URL . 'assets/css/style.css',
            [],
            \time() // Force cache bust
        );

        \wp_enqueue_script(
            'my-tiny-sandbox-js',
            \MTS_PLUGIN_URL . 'assets/js/script.js',
            ['jquery', 'jquery-ui-sortable'],
            \time(), // Force cache bust
            true
        );

        \wp_localize_script('my-tiny-sandbox-js', 'mtsData', [
            'ajax_url' => \admin_url('admin-ajax.php'),
            'nonce'    => \wp_create_nonce('mts_nonce'),
            'is_multisite' => \is_multisite(),
            'strings'  => [
                'confirm_delete' => \__('確定要刪除這個沙箱嗎？', 'my-tiny-sandbox'),
                'creating'       => \__('正在建立 WordPress 站台...', 'my-tiny-sandbox'),
                'multisite_error' => \__('此功能僅支援 WordPress Multisite 環境。', 'my-tiny-sandbox'),
            ]
        ]);
    }

    public function render_admin_page()
    {
        $user_id = \get_current_user_id();

        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);
        if (! \is_array($sandboxes)) $sandboxes = [];

        $trash = \get_user_meta($user_id, 'mts_sandbox_trash', true);
        if (! \is_array($trash)) $trash = [];

        require \MTS_PLUGIN_DIR . 'templates/admin-page.php';
    }

    private function render_card($sandbox, $index, $mode = 'active')
    {
        $url     = $sandbox['url'] ?? '';
        $name    = $sandbox['name'] ?? '';
        $id      = $sandbox['id'] ?? '';
        $created = $sandbox['created'] ?? '';

        // Check if site actually exists in FileSystem
        $is_active = isset($sandbox['path']) && \is_dir($sandbox['path']);

        if ($mode === 'trash') {
            $status_color = '#ef4444';
            $status_text  = \__('已刪除', 'my-tiny-sandbox');
        } else {
            $status_color = $is_active ? '#10b981' : '#9ca3af';
            $status_text  = $is_active ? \__('已部署', 'my-tiny-sandbox') : \__('找不到目錄/已失效', 'my-tiny-sandbox');
        }

?>
        <div class="sandbox-card <?php echo $mode === 'trash' ? 'trash-card' : ''; ?>" data-id="<?php echo \esc_attr($id); ?>" style="<?php echo $mode === 'trash' ? 'opacity: 0.8; border-color: #fca5a5;' : ''; ?>">
            <div class="card-header">
                <h3 class="card-title tooltip" data-tooltip="<?php echo \esc_attr($name); ?>">
                    <span class="dashicons dashicons-<?php echo $mode === 'trash' ? 'trash' : 'admin-generic'; ?>"></span>
                    <span class="title-text"><?php echo \esc_html($name); ?></span>
                    <?php
                    // Show Expiry Warning only in Active
                    if ($mode === 'active' && ! empty($sandbox['expiry_date'])) {
                        $expiry_ts = \strtotime($sandbox['expiry_date']);
                        $diff = $expiry_ts - \time();
                        if ($diff > 0) {
                            $hours_left = \ceil($diff / 3600);
                            $color = ($hours_left <= 2) ? '#ef4444' : '#f59e0b';
                            echo '<span class="dashicons dashicons-clock" style="color: ' . $color . '; font-size: 16px; margin-left: 5px;" title="' . \sprintf(\__('將在 %d 小時後刪除', 'my-tiny-sandbox'), $hours_left) . '"></span>';
                        }
                    }
                    ?>
                </h3>
                <div class="card-actions">
                    <div class="status-badge" style="background-color: <?php echo \esc_attr($status_color); ?>;">
                        <?php echo \esc_html($status_text); ?>
                    </div>

                    <?php if ($mode === 'active'): ?>
                        <?php if ($is_active && !empty($sandbox['magic_secret'])) : ?>
                            <button class="btn-magic-login tooltip"
                                data-tooltip="<?php \esc_attr_e('Magic Login (Admin)', 'my-tiny-sandbox'); ?>"
                                aria-label="<?php \esc_attr_e('Magic Login', 'my-tiny-sandbox'); ?>">
                                <span class="dashicons dashicons-admin-network"></span>
                            </button>
                        <?php endif; ?>

                        <!-- Stats Placeholders -->
                        <div class="sandbox-stat tooltip" data-tooltip="<?php \esc_attr_e('Disk Usage', 'my-tiny-sandbox'); ?>">
                            <span class="dashicons dashicons-media-default"></span>
                            <span class="stat-value disk-stat" data-id="<?php echo \esc_attr($sandbox['id']); ?>">...</span>
                        </div>
                        <div class="sandbox-stat tooltip" data-tooltip="<?php \esc_attr_e('DB Size', 'my-tiny-sandbox'); ?>">
                            <span class="dashicons dashicons-database"></span>
                            <span class="stat-value db-stat" data-id="<?php echo \esc_attr($sandbox['id']); ?>">...</span>
                        </div>

                        <button class="btn-delete tooltip"
                            data-tooltip="<?php \esc_attr_e('移至回收桶', 'my-tiny-sandbox'); ?>"
                            aria-label="<?php \esc_attr_e('Move to Trash', 'my-tiny-sandbox'); ?>">
                            <span class="dashicons dashicons-trash"></span>
                        </button>

                    <?php else: // Trash Mode 
                    ?>
                        <button class="btn-restore tooltip"
                            data-tooltip="<?php \esc_attr_e('還原沙箱', 'my-tiny-sandbox'); ?>"
                            style="color: #10b981;">
                            <span class="dashicons dashicons-undo"></span>
                        </button>
                        <button class="btn-force-delete tooltip"
                            data-tooltip="<?php \esc_attr_e('永久刪除', 'my-tiny-sandbox'); ?>"
                            style="color: #ef4444;">
                            <span class="dashicons dashicons-no"></span>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <div class="sandbox-info">
                    <span class="label"><?php \esc_html_e('URL:', 'my-tiny-sandbox'); ?></span>
                    <a href="<?php echo \esc_url($url); ?>" target="_blank" class="value tooltip" data-tooltip="<?php echo \esc_url($url); ?>">
                        <?php echo \esc_html($url); ?>
                    </a>
                </div>
                <div class="sandbox-info">
                    <span class="label"><?php echo $mode === 'trash' ? \esc_html__('刪除時間:', 'my-tiny-sandbox') : \esc_html__('建立日期:', 'my-tiny-sandbox'); ?></span>
                    <span class="value">
                        <?php echo $mode === 'trash' && isset($sandbox['deleted_at']) ? \esc_html($sandbox['deleted_at']) : \esc_html($created); ?>
                    </span>
                </div>
            </div>
            <?php if ($mode === 'active'): ?>
                <div class="card-footer">
                    <span class="drag-handle"><span class="dashicons dashicons-move"></span> <?php \esc_html_e('拖曳排序', 'my-tiny-sandbox'); ?></span>
                </div>
            <?php endif; ?>
        </div>
<?php
    }
}
