<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

use MyTinySandbox\Admin;
use MyTinySandbox\AjaxHandler;

class Main
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->load_dependencies();
    }

    private function load_dependencies()
    {
        Admin::get_instance();
        AjaxHandler::get_instance();
        SandboxService::get_instance();
    }
}
