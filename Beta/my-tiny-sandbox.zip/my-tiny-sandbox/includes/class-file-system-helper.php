<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

class FileSystemHelper
{

    /**
     * Recursively copy a directory.
     *
     * @param string $source
     * @param string $destination
     * @return bool
     */
    public static function copy_recursive($source, $destination)
    {
        if (! is_dir($source)) {
            return false;
        }

        if (! is_dir($destination)) {
            if (! mkdir($destination, 0755, true)) {
                return false;
            }
        }

        $dir = dir($source);
        while (false !== ($entry = $dir->read())) {
            if ($entry == '.' || $entry == '..') {
                continue;
            }

            $source_path = "$source/$entry";
            $dest_path   = "$destination/$entry";

            if (is_dir($source_path)) {
                self::copy_recursive($source_path, $dest_path);
            } else {
                copy($source_path, $dest_path);
            }
        }
        $dir->close();

        return true;
    }

    /**
     * Recursively delete a directory.
     *
     * @param string $dir
     * @return bool
     */
    public static function delete_recursive($dir)
    {
        if (! is_dir($dir)) {
            return false;
        }

        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = "$dir/$file";
            (is_dir($path)) ? self::delete_recursive($path) : unlink($path);
        }

        return rmdir($dir);
    }

    /**
     * Get directory size
     *
     * @param string $dir
     * @return float Size in MegaBytes (2 decimal precision)
     */
    public static function get_dir_size($dir)
    {
        if (! is_dir($dir)) {
            return 0;
        }

        $size = 0;
        foreach (new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir)) as $file) {
            $size += $file->getSize();
        }

        return \round($size / 1024 / 1024, 2);
    }
}
