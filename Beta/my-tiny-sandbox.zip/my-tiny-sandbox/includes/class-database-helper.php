<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

class DatabaseHelper
{

    /**
     * Drop all tables with a specific prefix.
     *
     * @param string $prefix
     * @return bool
     */
    /**
     * Validate prefix with strict safety guards.
     *
     * @param string $prefix
     * @return string|false Sanitized prefix on success, false on failure.
     */
    private static function validate_prefix($prefix)
    {
        global $wpdb;

        // Sanitize prefix to be safe (alphanumeric + underscore)
        $clean_prefix = preg_replace('/[^a-zA-Z0-9_]/', '', $prefix);

        // --- SAFETY GUARDS ---
        // 1. Empty Check
        if (empty($clean_prefix)) {
            error_log("MTS Error: Attempted to use empty prefix.");
            return false;
        }

        // 2. Main Site Protection (Critical!)
        if ($clean_prefix === $wpdb->prefix) {
            error_log("MTS CRITICAL: Attempted to use MAIN SITE prefix ($clean_prefix). Process Aborted.");
            return false;
        }

        // 3. Common Default Protection
        if ($clean_prefix === 'wp_') {
            error_log("MTS Warning: Attempted to use generic 'wp_' prefix. Process Aborted.");
            return false;
        }

        // 4. Sandbox Pattern Enforcement (Must start with sb_)
        if (strpos($clean_prefix, 'sb_') !== 0) {
            error_log("MTS Safety: Prefix '$clean_prefix' does not start with 'sb_'. Operation prevented.");
            return false;
        }

        return $clean_prefix;
    }

    /**
     * Get a list of tables that would be dropped for a specific prefix (Dry Run).
     *
     * @param string $prefix
     * @return array|false Array of table names or false on validation failure.
     */
    public static function get_tables_to_drop($prefix)
    {
        global $wpdb;

        $clean_prefix = self::validate_prefix($prefix);
        if ($clean_prefix === false) {
            return false;
        }

        // Escape for LIKE 'prefix%'
        $like = $wpdb->esc_like($clean_prefix) . '%';

        $tables = $wpdb->get_col($wpdb->prepare("SHOW TABLES LIKE %s", $like));

        return $tables;
    }

    /**
     * Drop all tables with a specific prefix.
     *
     * @param string $prefix
     * @return bool
     */
    public static function drop_tables_with_prefix($prefix)
    {
        global $wpdb;

        $tables = self::get_tables_to_drop($prefix);

        if ($tables === false) {
            return false; // Validation failed
        }

        if (empty($tables)) {
            return true; // No tables to drop, consider success
        }

        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS `$table`");
        }

        return true;
    }

    /**
     * Get total size of tables with specific prefix
     *
     * @param string $prefix
     * @return float Size in MegaBytes (2 decimal precision)
     */
    public static function get_tables_size($prefix)
    {
        global $wpdb;

        $prefix = preg_replace('/[^a-zA-Z0-9_]/', '', $prefix);
        if (empty($prefix)) return 0;

        // Escape for LIKE 'prefix%'
        $like = $wpdb->esc_like($prefix) . '%';

        $sql = "SELECT SUM(data_length + index_length) 
                FROM information_schema.TABLES 
                WHERE table_schema = %s 
                AND table_name LIKE %s";

        $size_bytes = $wpdb->get_var($wpdb->prepare($sql, \DB_NAME, $like));

        return round((float)$size_bytes / 1024 / 1024, 2);
    }
}
