<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

class AjaxHandler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        \add_action('wp_ajax_mts_create_site', [$this, 'create_site']);
        \add_action('wp_ajax_mts_delete_site', [$this, 'delete_site']); // Soft Delete
        \add_action('wp_ajax_mts_restore_site', [$this, 'restore_site']);
        \add_action('wp_ajax_mts_force_delete_site', [$this, 'force_delete_site']);
        \add_action('wp_ajax_mts_scan_orphans', [$this, 'scan_orphans']);
        \add_action('wp_ajax_mts_import_orphan', [$this, 'import_orphan']);
        \add_action('wp_ajax_mts_diagnose_site', [$this, 'diagnose_site']); // Health Check

        \add_action('wp_ajax_mts_preview_delete_site', [$this, 'preview_delete_site']); // Dry Run
        \add_action('wp_ajax_mts_save_order', [$this, 'save_order']);

        \add_action('wp_ajax_mts_check_base_dir', [$this, 'check_base_dir']);
        \add_action('wp_ajax_mts_get_magic_link', [$this, 'get_magic_link']);
        \add_action('wp_ajax_mts_get_stats', [$this, 'get_stats']);
    }

    /**
     * 檢查基礎目錄是否存在
     */
    public function check_base_dir()
    {
        \check_ajax_referer('mts_nonce', 'nonce');

        $base_dir = \ABSPATH . 'sandboxes/';
        if (! \is_dir($base_dir)) {
            // [IMPROVED] Instead of error, we tell frontend we will auto-init
            \wp_send_json_success([
                'auto_init' => true,
                'message'   => \__('初次使用，系統將自動初始化工作區...', 'my-tiny-sandbox')
            ]);
        }

        \wp_send_json_success(['auto_init' => false]);
    }

    /**
     * 建立獨立 WordPress 站台 (VPS 獨立檔案與資料庫)
     */
    /**
     * 建立獨立 WordPress 站台 (VPS 獨立檔案與資料庫)
     */
    public function create_site()
    {
        \check_ajax_referer('mts_nonce', 'nonce');

        $name = \sanitize_text_field($_POST['name'] ?? 'New Site');
        $auto_expiry = isset($_POST['auto_expiry']) && $_POST['auto_expiry'] == 1;

        $args = [];
        if ($auto_expiry) {
            $args['expiry_hours'] = 24;
        }

        $result = SandboxService::get_instance()->create_sandbox($name, $args);

        if ($result['success']) {
            \wp_send_json_success([
                'message'   => $result['message'],
                'sandbox'   => $result['data'],
                'debug_log' => $result['debug_log']
            ]);
        } else {
            \wp_send_json_error([
                'message'   => $result['message'],
                'debug_log' => $result['debug_log']
            ]);
        }
    }

    /**
     * 刪除獨立沙箱 (刪除檔案與資料庫)
     */
    /**
     * 刪除獨立沙箱 (刪除檔案與資料庫)
     */
    /**
     * 刪除獨立沙箱 (Moved to Recycle Bin)
     */
    public function delete_site()
    {
        \check_ajax_referer('mts_nonce', 'nonce');

        $sandbox_id = \sanitize_text_field($_POST['id'] ?? '');
        $result = SandboxService::get_instance()->soft_delete_sandbox($sandbox_id);

        if ($result['success']) {
            \wp_send_json_success(['message' => $result['message']]);
        } else {
            \wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * 還原沙箱
     */
    public function restore_site()
    {
        \check_ajax_referer('mts_nonce', 'nonce');
        $sandbox_id = \sanitize_text_field($_POST['id'] ?? '');
        $result = SandboxService::get_instance()->restore_sandbox($sandbox_id);

        if ($result['success']) {
            \wp_send_json_success(['message' => $result['message']]);
        } else {
            \wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * 永久刪除沙箱
     */
    public function force_delete_site()
    {
        \check_ajax_referer('mts_nonce', 'nonce');
        $sandbox_id = \sanitize_text_field($_POST['id'] ?? '');
        $result = SandboxService::get_instance()->force_delete_sandbox($sandbox_id);

        if ($result['success']) {
            \wp_send_json_success(['message' => $result['message']]);
        } else {
            \wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * 掃描 Orphaned Sandboxes
     */
    public function scan_orphans()
    {
        \check_ajax_referer('mts_nonce', 'nonce');
        $orphans = SandboxService::get_instance()->scan_orphans();
        \wp_send_json_success(['orphans' => $orphans]);
    }

    /**
     * 匯入 Orphaned Sandbox (至回收桶)
     */
    public function import_orphan()
    {
        \check_ajax_referer('mts_nonce', 'nonce');

        $orphan_data = $_POST['orphan_data'] ?? [];
        if (empty($orphan_data) || !is_array($orphan_data)) {
            \wp_send_json_error(['message' => 'Invalid Data']);
        }

        // Sanitize strict structure
        $clean_data = [
            'slug'      => \sanitize_text_field($orphan_data['slug']),
            'name'      => \sanitize_text_field($orphan_data['name']),
            'path'      => \sanitize_text_field($orphan_data['path']),
            'db_prefix' => \sanitize_text_field($orphan_data['db_prefix']),
            'url'       => \esc_url_raw($orphan_data['url']),
            'created'   => \sanitize_text_field($orphan_data['created']),
        ];

        $result = SandboxService::get_instance()->import_orphan($clean_data);

        if ($result['success']) {
            \wp_send_json_success(['message' => $result['message']]);
        } else {
            \wp_send_json_error(['message' => $result['message']]);
        }
    }

    /**
     * Preview Delete (Dry Run)
     */
    public function preview_delete_site()
    {
        \check_ajax_referer('mts_nonce', 'nonce');

        $sandbox_id = \sanitize_text_field($_POST['id'] ?? '');
        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);

        if (\is_array($sandboxes)) {
            foreach ($sandboxes as $item) {
                if ($item['id'] === $sandbox_id) {

                    // 1. Get Tables to Drop
                    $db_prefix = $item['db_prefix'] ?? '';
                    $tables = DatabaseHelper::get_tables_to_drop($db_prefix);

                    if ($tables === false) {
                        \wp_send_json_error(['message' => '前綴驗證失敗 (安全性檢查)，無法執行預覽']);
                    }

                    // 2. Prepare Data
                    \wp_send_json_success([
                        'sandbox_name' => $item['name'] ?? 'Unamed Sandbox',
                        'table_list'   => $tables,
                        'table_count'  => \count($tables),
                        'file_path'    => $item['path'] ?? ''
                    ]);
                }
            }
        }

        \wp_send_json_error(['message' => '找不到指定的沙箱 ID']);
    }


    /**
     * 儲存順序
     */
    public function save_order()
    {
        check_ajax_referer('mts_nonce', 'nonce');
        if (! current_user_can('manage_options')) wp_send_json_error();

        $order = $_POST['order'] ?? [];
        $user_id = get_current_user_id();
        $sandboxes = get_user_meta($user_id, 'mts_sandbox_list', true);

        if (is_array($sandboxes) && ! empty($order)) {
            $new_order_list = [];
            $sandboxes_map  = [];

            // 1. Build Map for quick lookup
            foreach ($sandboxes as $item) {
                if (isset($item['id'])) {
                    $sandboxes_map[$item['id']] = $item;
                }
            }

            // 2. Add items from $order
            foreach ($order as $id) {
                $id = sanitize_text_field($id);
                if (isset($sandboxes_map[$id])) {
                    $new_order_list[] = $sandboxes_map[$id];
                    unset($sandboxes_map[$id]); // Remove from map so we know it's handled
                }
            }

            // 3. Append remaining items (Safe-guard against data loss)
            // If the frontend didn't send some IDs (e.g. pagination or bug), we preserve them at the end.
            if (! empty($sandboxes_map)) {
                foreach ($sandboxes_map as $item) {
                    $new_order_list[] = $item;
                }
            }

            update_user_meta($user_id, 'mts_sandbox_list', $new_order_list);
            wp_send_json_success();
        }
        wp_send_json_error();
    }

    /**
     * 取得 Magic Login 連結
     */
    public function get_magic_link()
    {
        \check_ajax_referer('mts_nonce', 'nonce');
        if (! \current_user_can('manage_options')) \wp_send_json_error();

        $sandbox_id = \sanitize_text_field($_POST['id'] ?? '');
        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);

        if (\is_array($sandboxes)) {
            foreach ($sandboxes as $item) {
                if ($item['id'] === $sandbox_id) {
                    if (empty($item['magic_secret'])) {
                        \wp_send_json_error(['message' => '此沙箱未啟用 Magic Login (可能為舊版)']);
                    }

                    // Generate Link
                    $timestamp = \time();
                    $signature = \hash_hmac('sha256', (string)$timestamp, $item['magic_secret']);

                    // Ensure trailing slash for URL
                    $url = \untrailingslashit($item['url']) . '/';
                    $login_url = $url . '?mts_action=magic_login&ts=' . $timestamp . '&sig=' . $signature;

                    \wp_send_json_success(['url' => $login_url]);
                }
            }
        }

        \wp_send_json_error(['message' => '找不到沙箱']);
    }
    /**
     * 取得統計數據
     */
    public function get_stats()
    {
        $sandbox_id = isset($_POST['id']) ? \sanitize_text_field($_POST['id']) : '';
        if (empty($sandbox_id)) {
            \wp_send_json_error();
        }

        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);

        $target_sandbox = null;
        if (\is_array($sandboxes)) {
            foreach ($sandboxes as $item) {
                if ($item['id'] === $sandbox_id) {
                    $target_sandbox = $item;
                    break;
                }
            }
        }

        if (! $target_sandbox) {
            \wp_send_json_error();
        }

        // Calculate Stats
        $disk_usage = FileSystemHelper::get_dir_size($target_sandbox['path']);
        $db_size    = DatabaseHelper::get_tables_size($target_sandbox['db_prefix']);

        \wp_send_json_success([
            'disk_usage' => $disk_usage,
            'db_size'    => $db_size
        ]);
    }
}
