<?php

namespace MyTinySandbox;

if (! defined('ABSPATH')) {
    exit;
}

use MyTinySandbox\FileSystemHelper;
use MyTinySandbox\DatabaseHelper;

/**
 * Service class for handling Sandbox business logic
 */
class SandboxService
{
    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Create a new sandbox environment
     *
     * @param string $name Sandbox Name
     * @return array Result ['success' => bool, 'message' => string, 'data' => array, 'debug_log' => array]
     */
    /**
     * Create a new sandbox environment
     *
     * @param string $name Sandbox Name
     * @param array $args Optional arguments (e.g. ['expiry_hours' => 24])
     * @return array Result ['success' => bool, 'message' => string, 'data' => array, 'debug_log' => array]
     */
    public function create_sandbox($name, $args = [])
    {
        $debug_log = [];
        $debug_log[] = 'Starting create_sandbox service...';

        if (! \current_user_can('manage_options')) {
            return ['success' => false, 'message' => \__('權限不足', 'my-tiny-sandbox'), 'debug_log' => $debug_log];
        }

        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);
        if (! \is_array($sandboxes)) $sandboxes = [];

        // Capture Parent Site Settings (Language & Timezone)
        $parent_locale     = \get_locale();
        $parent_tz_string  = \get_option('timezone_string');
        $parent_gmt_offset = \get_option('gmt_offset');


        // 1. Prepare Identifiers
        $timestamp = \time();
        $slug      = 'site_' . \substr(\md5(\uniqid()), 0, 8);

        $sandbox_root = \ABSPATH . 'sandboxes/' . $slug . '/';
        $wpcore_dir   = $sandbox_root . 'wpcore/';

        $debug_log[] = "Identifiers prepared. Slug: $slug";
        $debug_log[] = "Root Path: $sandbox_root";

        // Start Transactional Logic
        global $wpdb;
        $original_prefix = $wpdb->prefix;

        try {
            // 2. Prepare File System
            $this->prepare_filesystem($wpcore_dir, $debug_log);


            // 4. Database Setup
            $safe_slug = \str_replace('-', '_', $slug);
            $db_prefix = 'sb_' . $safe_slug . '_';
            $debug_log[] = "Using Table Prefix: $db_prefix";

            // 5. Generate Secret Key & 6. Config
            // Calculate Site URL
            $site_url = \home_url('/sandboxes/' . $slug . '/wpcore');

            $magic_secret = $this->generate_config($wpcore_dir, $db_prefix, $site_url, $debug_log);


            // 7. Auto-Install WordPress
            $this->install_database($name, $db_prefix, $site_url, $debug_log);


            // Restore Prefix
            $wpdb->set_prefix($original_prefix);

            // 8. Finalize Sandbox
            $new_sandbox = $this->finalize_sandbox($wpcore_dir, $slug, $db_prefix, $name, $site_url, $sandbox_root, $magic_secret, $args, $timestamp, $user_id);


            $debug_log[] = "Meta updated. Transaction Complete.";

            return [
                'success' => true,
                'message' => \__('獨立沙箱建立成功！已自動安裝 WordPress 與 Magic Login。', 'my-tiny-sandbox'),
                'data'    => $new_sandbox,
                'debug_log' => $debug_log
            ];
        } catch (\Exception $e) {
            // === ROLLBACK ===
            $debug_log[] = "CRITICAL ERROR: " . $e->getMessage();
            $debug_log[] = "Initiating Rollback...";

            // 1. Restore Global State
            $wpdb->set_prefix($original_prefix);

            // 2. Drop DB Tables
            if (isset($db_prefix)) {
                $debug_log[] = "Rollback: Dropping tables $db_prefix...";
                DatabaseHelper::drop_tables_with_prefix($db_prefix);
            }

            // 3. Delete Files
            if (isset($sandbox_root) && \is_dir($sandbox_root)) {
                $debug_log[] = "Rollback: Deleting files at $sandbox_root...";
                FileSystemHelper::delete_recursive($sandbox_root);
            }

            return [
                'success' => false,
                'message' => '建立失敗 (已自動還原清除): ' . $e->getMessage(),
                'debug_log' => $debug_log
            ];
        }
    }

    /**
     * Prepare file system for the new sandbox
     *
     * @param string $wpcore_dir
     * @param array $debug_log Passed by reference
     * @throws \Exception
     */
    private function prepare_filesystem($wpcore_dir, &$debug_log)
    {
        // 2. Create Directors
        if (! \is_dir($wpcore_dir)) {
            if (! \mkdir($wpcore_dir, 0755, true)) {
                throw new \Exception(\__('無法建立沙箱目錄', 'my-tiny-sandbox'));
            }
        }
        $debug_log[] = "Directory created: $wpcore_dir";

        // Security: Protect Sandboxes Root
        $sandboxes_root = \dirname($wpcore_dir, 2);
        if (\is_dir($sandboxes_root)) {
            // 1. Silence is Golden
            if (! \file_exists($sandboxes_root . '/index.php')) {
                \file_put_contents($sandboxes_root . '/index.php', "<?php\n// Silence is golden");
            }
            // 2. .htaccess Protection
            if (! \file_exists($sandboxes_root . '/.htaccess')) {
                \file_put_contents($sandboxes_root . '/.htaccess', "Options -Indexes\n\n<FilesMatch \"\.(log|txt|md|sql)\">\nOrder allow,deny\nDeny from all\n</FilesMatch>");
            }
        }


        // 3. Clone WordPress Core
        $core_folders = ['wp-admin', 'wp-includes'];
        foreach ($core_folders as $folder) {
            $source = \ABSPATH . $folder;
            $dest   = $wpcore_dir . $folder;

            if (! FileSystemHelper::copy_recursive($source, $dest)) {
                throw new \Exception("複製核心資料夾失敗: $folder");
            }
        }
        $debug_log[] = "Core folders copied.";

        // Copy root .php files
        $root_files = \glob(\ABSPATH . '*.php');
        foreach ($root_files as $file) {
            $filename = \basename($file);
            if ($filename === 'wp-config.php') continue;

            if (! \copy($file, $wpcore_dir . $filename)) {
                // Strict Mode: If root file copy fails (e.g. index.php), abort
                throw new \Exception("複製核心檔案失敗: $filename");
            }
        }
        $debug_log[] = "Root PHP files copied.";

        // Create wp-content structure
        if (! \is_dir($wpcore_dir . 'wp-content')) \mkdir($wpcore_dir . 'wp-content', 0755);

        // 1. Copy Themes
        $source_themes = \ABSPATH . 'wp-content/themes';
        $dest_themes   = $wpcore_dir . 'wp-content/themes';
        if (\is_dir($source_themes)) {
            FileSystemHelper::copy_recursive($source_themes, $dest_themes);
        } else {
            \mkdir($dest_themes, 0755);
        }

        // 2. Copy Languages
        $source_langs = \ABSPATH . 'wp-content/languages';
        $dest_langs   = $wpcore_dir . 'wp-content/languages';
        if (\is_dir($source_langs)) {
            FileSystemHelper::copy_recursive($source_langs, $dest_langs);
        }

        // 3. Create other standard folders
        if (! \is_dir($wpcore_dir . 'wp-content/plugins')) \mkdir($wpcore_dir . 'wp-content/plugins', 0755);
        if (! \is_dir($wpcore_dir . 'wp-content/uploads')) \mkdir($wpcore_dir . 'wp-content/uploads', 0755);

        $debug_log[] = "wp-content populated.";
    }

    /**
     * Generate wp-config.php
     *
     * @param string $wpcore_dir
     * @param string $db_prefix
     * @param string $site_url
     * @param array $debug_log Passed by reference
     * @return string Magic Secret
     * @throws \Exception
     */
    private function generate_config($wpcore_dir, $db_prefix, $site_url, &$debug_log)
    {
        $wp_config_sample = \ABSPATH . 'wp-config-sample.php';
        if (! \file_exists($wp_config_sample)) {
            $wp_config_sample = $wpcore_dir . 'wp-config-sample.php';
        }

        if (! \file_exists($wp_config_sample)) {
            throw new \Exception("wp-config-sample.php missing.");
        }

        $config_content = \file_get_contents($wp_config_sample);

        // Basic DB Config
        $config_content = \str_replace('database_name_here', \DB_NAME, $config_content);
        $config_content = \str_replace('username_here', \DB_USER, $config_content);
        $config_content = \str_replace('password_here', \DB_PASSWORD, $config_content);
        $config_content = \str_replace('localhost', \DB_HOST, $config_content);

        // Set Table Prefix
        $config_content = \str_replace('$table_prefix = \'wp_\';', '$table_prefix = \'' . $db_prefix . '\';', $config_content);
        if (\strpos($config_content, '$table_prefix = \'' . $db_prefix . '\'') === false) {
            $config_content = \preg_replace('/\$table_prefix\s*=\s*[\'"]wp_[\'"]\s*;/', '$table_prefix = \'' . $db_prefix . '\';', $config_content);
        }

        // Generate Salts
        $salts = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'];
        foreach ($salts as $salt) {
            $random_key = \wp_generate_password(64, true, true);
            $config_content = \preg_replace(
                "/define\s*\(\s*['\"]" . $salt . "['\"]\s*,\s*['\"]put your unique phrase here['\"]\s*\);/",
                "define( '$salt', '$random_key' );",
                $config_content
            );
        }

        // Constants
        $debug_const = "define( 'WP_DEBUG', true );\ndefine( 'WP_DEBUG_LOG', true );\ndefine( 'WP_DEBUG_DISPLAY', true );";
        $config_content = \str_replace("define( 'WP_DEBUG', false );", $debug_const, $config_content);

        // Generate Magic Secret
        $magic_secret = \wp_generate_password(64, true, true);
        $secret_const = "define('MTS_MAGIC_SECRET', '" . $magic_secret . "');";
        $config_content = \str_replace('/* That\'s all, stop editing', $secret_const . "\n/* That's all, stop editing", $config_content);

        $urls_const = "define('WP_HOME', '" . $site_url . "');\ndefine('WP_SITEURL', '" . $site_url . "');";
        $config_content = \str_replace('/* That\'s all, stop editing', $urls_const . "\n/* That's all, stop editing", $config_content);

        if (\file_put_contents($wpcore_dir . 'wp-config.php', $config_content) === false) {
            throw new \Exception("Failed to write wp-config.php");
        }
        $debug_log[] = "wp-config.php generated.";

        return $magic_secret;
    }

    /**
     * Install WordPress Database & Admin User
     *
     * @param string $name
     * @param string $db_prefix
     * @param string $site_url
     * @param array $debug_log Passed by reference
     * @return int User ID
     * @throws \Exception
     */
    private function install_database($name, $db_prefix, $site_url, &$debug_log)
    {
        global $wpdb;

        $debug_log[] = "Running WordPress Installation...";
        if (!\function_exists('wp_install')) {
            require_once \ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        $wpdb->set_prefix($db_prefix);

        // Run Install
        $admin_password = \wp_generate_password(12, false);
        $install_result = \wp_install($name, 'admin', 'admin@example.com', false, '', $admin_password);

        if (! \is_array($install_result) || empty($install_result['user_id'])) {
            throw new \Exception("WordPress Install Function failed silently or returned invalid data.");
        }

        // --- Post Install Logic ---
        \update_option('siteurl', $site_url);
        \update_option('home', $site_url);

        // Capture Parent Site Settings (Language & Timezone)
        $parent_locale     = \get_locale();
        $parent_tz_string  = \get_option('timezone_string');
        $parent_gmt_offset = \get_option('gmt_offset');

        if (! empty($parent_locale)) \update_option('WPLANG', $parent_locale);
        if (! empty($parent_tz_string)) \update_option('timezone_string', $parent_tz_string);
        if ($parent_gmt_offset !== false) \update_option('gmt_offset', $parent_gmt_offset);

        $debug_log[] = "Installation complete. Admin User Created.";

        // FORCE FIX CAPABILITIES
        $user_id = $install_result['user_id'];
        $cap_key = $db_prefix . 'capabilities';
        $level_key = $db_prefix . 'user_level';

        if (! \function_exists('populate_roles')) {
            require_once \ABSPATH . 'wp-admin/includes/schema.php';
        }
        \populate_roles();

        \update_user_meta($user_id, $cap_key, ['administrator' => true]);
        \update_user_meta($user_id, $level_key, 10);

        $debug_log[] = "User Capabilities fixed.";

        return $user_id;
    }

    /**
     * Finalize Sandbox (Magic Login & Meta Update)
     *
     * @param string $wpcore_dir
     * @param string $slug
     * @param string $db_prefix
     * @param string $name
     * @param string $site_url
     * @param string $sandbox_root
     * @param string $magic_secret
     * @param array $args
     * @param int $timestamp
     * @param int $user_id
     * @return array New Sandbox Data
     */
    private function finalize_sandbox($wpcore_dir, $slug, $db_prefix, $name, $site_url, $sandbox_root, $magic_secret, $args, $timestamp, $user_id)
    {
        // 8. Inject Magic Login
        $mu_plugins_dir = $wpcore_dir . 'wp-content/mu-plugins/';
        if (! \is_dir($mu_plugins_dir)) \mkdir($mu_plugins_dir, 0755, true);

        $template_path = \MTS_PLUGIN_DIR . 'templates/mts-magic-login.php';
        if (\file_exists($template_path)) {
            \copy($template_path, $mu_plugins_dir . 'mts-magic-login.php');
        }

        // 9. Finalize Meta
        $new_id  = 'sb_' . $timestamp;
        $new_sandbox = [
            'id'           => $new_id,
            'slug'         => $slug,
            'db_prefix'    => $db_prefix,
            'name'         => $name,
            'url'          => $site_url,
            'path'         => $sandbox_root,
            'magic_secret' => $magic_secret,
            'created'      => \current_time('Y-m-d H:i:s')
        ];

        // Handle Expiry
        if (isset($args['expiry_hours']) && \is_numeric($args['expiry_hours'])) {
            $hours = (int)$args['expiry_hours'];
            $new_sandbox['expiry_date'] = \date('Y-m-d H:i:s', \time() + ($hours * 3600));
            $new_sandbox['expiry_hours'] = $hours; // Store for reference
        }

        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);
        if (! \is_array($sandboxes)) $sandboxes = [];

        \array_unshift($sandboxes, $new_sandbox);
        \update_user_meta($user_id, 'mts_sandbox_list', $sandboxes);

        return $new_sandbox;
    }

    /**
     * Soft Delete a sandbox (Move to Trash)
     */
    public function soft_delete_sandbox($sandbox_id)
    {
        if (! \current_user_can('manage_options')) return ['success' => false, 'message' => \__('權限不足', 'my-tiny-sandbox')];

        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);
        if (! \is_array($sandboxes)) $sandboxes = [];

        $trash = \get_user_meta($user_id, 'mts_sandbox_trash', true);
        if (! \is_array($trash)) $trash = [];

        $found = false;
        foreach ($sandboxes as $key => $item) {
            if ($item['id'] === $sandbox_id) {
                $item['deleted_at'] = \current_time('Y-m-d H:i:s');
                $trash[] = $item;
                unset($sandboxes[$key]);
                $found = true;
                break;
            }
        }

        if ($found) {
            \update_user_meta($user_id, 'mts_sandbox_list', \array_values($sandboxes));
            \update_user_meta($user_id, 'mts_sandbox_trash', $trash);
            return ['success' => true, 'message' => \__('沙箱已移至回收桶', 'my-tiny-sandbox')];
        }

        return ['success' => false, 'message' => \__('找不到指定的沙箱', 'my-tiny-sandbox')];
    }

    /**
     * Restore a sandbox from Trash
     */
    public function restore_sandbox($sandbox_id)
    {
        if (! \current_user_can('manage_options')) return ['success' => false, 'message' => \__('權限不足', 'my-tiny-sandbox')];

        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);
        if (! \is_array($sandboxes)) $sandboxes = [];

        $trash = \get_user_meta($user_id, 'mts_sandbox_trash', true);
        if (! \is_array($trash)) return ['success' => false, 'message' => \__('回收桶是空的', 'my-tiny-sandbox')];

        $found = false;
        foreach ($trash as $key => $item) {
            if ($item['id'] === $sandbox_id) {
                unset($item['deleted_at']); // Remove timestamp
                $sandboxes[] = $item; // Move back to active list
                unset($trash[$key]);
                $found = true;
                break;
            }
        }

        if ($found) {
            \update_user_meta($user_id, 'mts_sandbox_list', \array_values($sandboxes)); // Values reset keys
            \update_user_meta($user_id, 'mts_sandbox_trash', \array_values($trash));
            return ['success' => true, 'message' => \__('沙箱已還原', 'my-tiny-sandbox')];
        }

        return ['success' => false, 'message' => \__('在回收桶中找不到此沙箱', 'my-tiny-sandbox')];
    }

    /**
     * Permanently Delete a sandbox (From Trash)
     */
    public function force_delete_sandbox($sandbox_id)
    {
        if (! \current_user_can('manage_options')) {
            return ['success' => false, 'message' => \__('權限不足', 'my-tiny-sandbox')];
        }

        $user_id = \get_current_user_id();
        $trash = \get_user_meta($user_id, 'mts_sandbox_trash', true);

        if (! \is_array($trash)) {
            return ['success' => false, 'message' => \__('回收桶是空的', 'my-tiny-sandbox')];
        }

        $found = false;
        foreach ($trash as $key => $item) {
            if ($item['id'] === $sandbox_id) {
                // 1. Drop Tables
                if (isset($item['db_prefix'])) {
                    DatabaseHelper::drop_tables_with_prefix($item['db_prefix']);
                }

                // 2. Delete Files
                if (isset($item['path']) && \is_dir($item['path'])) {
                    FileSystemHelper::delete_recursive($item['path']);
                }

                unset($trash[$key]);
                $found = true;
                break;
            }
        }

        if ($found) {
            $trash = \array_values($trash); // Reindex
            \update_user_meta($user_id, 'mts_sandbox_trash', $trash);
            return ['success' => true, 'message' => \__('沙箱已永久刪除', 'my-tiny-sandbox')];
        }

        return ['success' => false, 'message' => \__('找不到指定的沙箱 ID', 'my-tiny-sandbox')];
    }

    /**
     * Scan for Orphaned Sandboxes (Files exist but not in DB List or Trash)
     */
    public function scan_orphans()
    {
        if (! \current_user_can('manage_options')) return [];

        $user_id = \get_current_user_id();
        $active_list = \get_user_meta($user_id, 'mts_sandbox_list', true) ?: [];
        $trash_list  = \get_user_meta($user_id, 'mts_sandbox_trash', true) ?: [];

        // Collect all Known IDs / Slugs
        $known_slugs = [];
        foreach ($active_list as $s) {
            if (isset($s['slug'])) $known_slugs[] = $s['slug'];
        }
        foreach ($trash_list as $s) {
            if (isset($s['slug'])) $known_slugs[] = $s['slug'];
        }

        // Scan Directory
        $base_dir = \ABSPATH . 'sandboxes/';
        if (! \is_dir($base_dir)) return [];

        $found_orphans = [];
        $dirs = \glob($base_dir . 'site_*', \GLOB_ONLYDIR);

        foreach ($dirs as $dir_path) {
            $slug = \basename($dir_path);
            if (! \in_array($slug, $known_slugs)) {
                // Found an orphan!
                // Try to guess prefix and other data
                $safe_slug = \str_replace('-', '_', $slug);
                $db_prefix = 'sb_' . $safe_slug . '_';

                // Check if options table exists (Validity Check)
                global $wpdb;
                $table_check = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $db_prefix . 'options'));

                if ($table_check) {
                    $found_orphans[] = [
                        'id'        => 'found_' . $slug, // Temp ID
                        'slug'      => $slug,
                        'name'      => 'Recovered ' . $slug, // Placeholder
                        'path'      => $dir_path,
                        'db_prefix' => $db_prefix,
                        'url'       => \home_url('/sandboxes/' . $slug . '/wpcore'),
                        'created'   => \date('Y-m-d H:i:s', \filemtime($dir_path)) // Guess time from folder
                    ];
                }
            }
        }

        return $found_orphans;
    }

    /**
     * Diagnose a Sandbox (Health Check)
     *
     * @param string $sandbox_id
     * @return array ['status' => 'healthy'|'warning'|'error', 'issues' => [], 'data' => ...]
     */
    public function diagnose_site($sandbox_id)
    {
        $user_id = \get_current_user_id();
        $sandboxes = \get_user_meta($user_id, 'mts_sandbox_list', true);

        $target = null;
        if (\is_array($sandboxes)) {
            foreach ($sandboxes as $sb) {
                if ($sb['id'] === $sandbox_id) {
                    $target = $sb;
                    break;
                }
            }
        }

        if (! $target) {
            return ['status' => 'error', 'message' => 'Sandbox not found in registry.'];
        }

        $issues = [];
        $status = 'healthy';

        // 1. Check Filesystem
        if (! isset($target['path']) || ! \is_dir($target['path'])) {
            $status = 'error';
            $issues[] = 'Filesystem Directory Missing: ' . ($target['path'] ?? 'Unknown Path');
        } else {
            // Check wp-config.php
            if (! \file_exists($target['path'] . '/wpcore/wp-config.php')) {
                $status = 'error'; // Critical
                $issues[] = 'wp-config.php is missing.';
            }
        }

        // 2. Check Database
        if (isset($target['db_prefix'])) {
            global $wpdb;
            $prefix = $target['db_prefix'];
            // Check Critical Tables: options, users, posts
            $tables = ['options', 'users', 'posts'];
            $missing_tables = [];

            foreach ($tables as $t) {
                $table_name = $prefix . $t;
                if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_name)) !== $table_name) {
                    $missing_tables[] = $table_name;
                }
            }

            if (! empty($missing_tables)) {
                $status = ($status === 'error') ? 'error' : 'warning'; // If files missing, already error. Else warning.
                $issues[] = 'Database Tables Missing: ' . \implode(', ', $missing_tables);
            }
        } else {
            $issues[] = 'Database Prefix not defined in metadata.';
            $status = 'error';
        }

        return [
            'status' => $status,
            'issues' => $issues,
            'data'   => $target
        ];
    }

    /**
     * Import an Orphan to Trash
     */
    public function import_orphan($orphan_data)
    {
        $user_id = \get_current_user_id();
        $trash = \get_user_meta($user_id, 'mts_sandbox_trash', true) ?: [];

        // Generate a proper ID
        $orphan_data['id'] = 'sb_' . \time() . '_' . \rand(100, 999);
        $orphan_data['deleted_at'] = \current_time('Y-m-d H:i:s');

        // Try to recover Magic Secret from wp-config.php
        $config_path = $orphan_data['path'] . '/wpcore/wp-config.php';
        if (\file_exists($config_path)) {
            $content = \file_get_contents($config_path);
            if (\preg_match("/define\('MTS_MAGIC_SECRET', '(.*?)'\);/", $content, $matches)) {
                $orphan_data['magic_secret'] = $matches[1];
            }
        }

        $trash[] = $orphan_data;
        \update_user_meta($user_id, 'mts_sandbox_trash', $trash);

        return ['success' => true, 'message' => \__('已成功還原至回收桶，請至回收桶查看。', 'my-tiny-sandbox')];
    }

    /**
     * Cron Job: Cleanup expired sandboxes
     */
    public static function scheduled_cleanup()
    {
        $users = \get_users(); // Can be expensive on large sites, but fine for local/dev
        $now   = \current_time('timestamp');

        foreach ($users as $user) {
            $sandboxes = \get_user_meta($user->ID, 'mts_sandbox_list', true);
            if (! \is_array($sandboxes) || empty($sandboxes)) continue;

            $modified = false;
            // Iterate backwards to safely unlink
            for ($i = count($sandboxes) - 1; $i >= 0; $i--) {
                $sb = $sandboxes[$i];
                if (isset($sb['expiry_date']) && !empty($sb['expiry_date'])) {
                    $expiry_ts = \strtotime($sb['expiry_date']);
                    if ($expiry_ts < $now) {
                        // Expired! Delete it.
                        // 1. Drop Tables
                        if (isset($sb['db_prefix'])) {
                            DatabaseHelper::drop_tables_with_prefix($sb['db_prefix']);
                        }

                        // 2. Delete Files
                        if (isset($sb['path']) && \is_dir($sb['path'])) {
                            FileSystemHelper::delete_recursive($sb['path']);
                        }

                        \error_log("MTS Auto-Cleanup: Deleted sandbox {$sb['id']} (Expired at {$sb['expiry_date']})");
                        unset($sandboxes[$i]);
                        $modified = true;
                    }
                }
            }

            if ($modified) {
                $sandboxes = \array_values($sandboxes);
                \update_user_meta($user->ID, 'mts_sandbox_list', $sandboxes);
            }
        }
    }
}
