jQuery(document).ready(function ($) {

    const grid = $('#sandbox-grid-container');
    const messageContainer = $('#sandbox-message-container');

    function showMessage(message, type) {
        let msgHtml = '<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>';
        $('#sandbox-message-container').html(msgHtml);
    }

    function fetchStats() {
        $('.stat-value.disk-stat').each(function () {
            const span = $(this);
            const id = span.data('id');
            const card = span.closest('.sandbox-card');
            const dbSpan = card.find('.stat-value.db-stat');

            $.ajax({
                url: mtsData.ajax_url,
                type: 'POST',
                data: {
                    action: 'mts_get_stats',
                    nonce: mtsData.nonce,
                    id: id
                },
                success: function (response) {
                    if (response.success) {
                        span.text(response.data.disk_usage + ' MB');
                        dbSpan.text(response.data.db_size + ' MB');
                    } else {
                        span.text('-');
                        dbSpan.text('-');
                    }
                }
            });
        });
    }

    // Initial Fetch
    fetchStats();

    // Create Isolated Site
    // Logger function
    function logDebug(msg) {
        const logArea = $('#mts-debug-log');
        const container = $('#mts-debug-log-container');
        container.show();

        const timestamp = new Date().toLocaleTimeString();
        logArea.val(logArea.val() + `[${timestamp}] ${msg}\n`);
        logArea.scrollTop(logArea[0].scrollHeight);
    }

    function showToast(msg, type = 'success') {
        const icon = type === 'success' ? 'dashicons-yes-alt' : 'dashicons-warning';
        const html = `
            <div class="mts-toast ${type}">
                <span class="dashicons ${icon}"></span>
                <span>${msg}</span>
            </div>
        `;
        const toast = $(html).appendTo('body');

        // Trigger generic animation
        setTimeout(() => toast.addClass('show'), 10);

        // Auto remove
        setTimeout(() => {
            toast.removeClass('show');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    // Create Isolated Site
    $('#create-sandbox-btn').on('click', function () {
        const btn = $(this);
        const originalText = btn.html();

        // [LOCK] Immediate lock to prevent double clicks
        btn.prop('disabled', true).html('<span class="dashicons dashicons-update-alt spin"></span> 準備中...');

        // Clear log
        $('#mts-debug-log').val('');
        logDebug('開始建立程序...');

        // 1. Pre-check: Does "sandboxes" directory exist?
        logDebug('正在檢查沙箱根目錄...');

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_check_base_dir',
                nonce: mtsData.nonce
            },
            success: function (checkResponse) {
                // [IMPROVED] Check logic
                if (checkResponse.success) {
                    if (checkResponse.data && checkResponse.data.auto_init) {
                        logDebug('提示：' + checkResponse.data.message);
                        showToast(checkResponse.data.message, 'success'); // Using success/blue toast for info
                    } else {
                        logDebug('目錄檢查通過。');
                    }
                } else {
                    // Fallback for real errors (permissions etc)
                    logDebug('警告：' + (checkResponse.data ? checkResponse.data.message : 'Unknown Error'));
                    // [UNLOCK] Check failed
                    btn.prop('disabled', false).html(originalText);
                    alert(checkResponse.data ? checkResponse.data.message : 'Directory Check Failed');
                    return; // Stop execution
                }

                // 2. Proceed with creation

                // 2. Proceed with creation
                // Slight delay to allow UI to render the "Ready" state if needed, but not strictly necessary.
                // Using setTimeout to ensure the UI lock renders before alert/prompt blocks thread (browser dependent).
                setTimeout(function () {
                    const name = prompt('請輸入新站點名稱:', 'My New Site');
                    if (!name) {
                        logDebug('使用者取消建立。');
                        // [UNLOCK] User cancelled
                        btn.prop('disabled', false).html(originalText);
                        return;
                    }

                    logDebug('使用者輸入名稱：' + name);
                    // Update status text
                    btn.html('<span class="dashicons dashicons-update-alt spin"></span> ' + mtsData.strings.creating);
                    logDebug('發送建立請求至後端...');

                    $.ajax({
                        url: mtsData.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'mts_create_site',
                            nonce: mtsData.nonce,
                            name: name,
                            auto_expiry: $('#mts-auto-expiry').is(':checked') ? 1 : 0
                        },
                        success: function (response) {
                            // Append backend logs if available
                            if (response.data && response.data.debug_log) {
                                response.data.debug_log.forEach(function (logItem) {
                                    logDebug('[Backend] ' + logItem);
                                });
                            }

                            if (response.success) {
                                logDebug('建立成功！正在重新整理頁面...');
                                showMessage(response.data.message, 'success');
                                // [LOCK] Keep locked until reload
                                setTimeout(() => location.reload(), 1000);
                            } else {
                                logDebug('錯誤：' + response.data.message);
                                showMessage(response.data.message, 'error');
                                // [UNLOCK] Creation failed
                                btn.prop('disabled', false).html(originalText);
                            }
                        },
                        error: function (xhr, status, error) {
                            logDebug('AJAX 請求失敗 (HTTP 500/Timeout?)');
                            logDebug('Status: ' + status);
                            logDebug('Error: ' + error);
                            logDebug('Response: ' + xhr.responseText);

                            showMessage('系統錯誤，請檢查網路連線', 'error');
                            // [UNLOCK] AJAX error
                            btn.prop('disabled', false).html(originalText);
                        }
                    });
                }, 50); // Small delay for UI update
            },
            error: function (xhr, status, error) {
                logDebug('目錄檢查請求失敗。');
                logDebug('Error: ' + error);
                showMessage('無法連接到伺服器進行目錄檢查，請查看後端錯誤紀錄。', 'error');
                // [UNLOCK] Check request failed
                btn.prop('disabled', false).html(originalText);
            }
        });
    });

    // --- TAB LOGIC ---
    $('.mts-filter-tabs a').on('click', function (e) {
        e.preventDefault();
        const tab = $(this).data('tab');

        // Update Nav
        $('.mts-filter-tabs a').removeClass('current');
        $(this).addClass('current');

        // Update View
        $('.sandbox-grid').hide();
        $('#sandbox-grid-' + tab).show();

        if (tab === 'trash') {
            checkOrphans();
        }
    });

    // --- ORPHAN LOGIC ---
    let orphanCheckRun = false;
    function checkOrphans() {
        if (orphanCheckRun) return;
        orphanCheckRun = true;

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: { action: 'mts_scan_orphans', nonce: mtsData.nonce },
            success: function (resp) {
                if (resp.success && resp.data.orphans.length > 0) {
                    const list = $('#mts-orphan-list');
                    list.empty();
                    resp.data.orphans.forEach(site => {
                        list.append(`<div>Found: <strong>${site.name}</strong> (${site.path})</div>`);
                    });

                    $('#mts-orphan-alert').fadeIn();

                    // Bind Import
                    $('#mts-import-orphans-btn').off('click').on('click', function (e) {
                        e.preventDefault();
                        const btn = $(this);
                        btn.prop('disabled', true).text('Restoring...');

                        let promises = resp.data.orphans.map(orphan => {
                            return $.ajax({
                                url: mtsData.ajax_url,
                                type: 'POST',
                                data: {
                                    action: 'mts_import_orphan',
                                    nonce: mtsData.nonce,
                                    orphan_data: orphan
                                }
                            });
                        });

                        Promise.all(promises).then(() => {
                            location.reload();
                        });
                    });
                }
            }
        });
    }


    // --- ACTION: SOFT DELETE (Move to Trash) ---
    $(document).on('click', '.btn-delete', function (e) {
        e.preventDefault();
        if (!confirm(mtsData.strings.confirm_delete || '確定要移至回收桶嗎？')) return;

        const btn = $(this);
        const card = btn.closest('.sandbox-card');
        const id = card.data('id');

        // UI Feedback
        btn.prop('disabled', true);
        const originalIcon = btn.find('.dashicons').attr('class');
        btn.find('.dashicons').attr('class', 'dashicons dashicons-update-alt spin');

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_delete_site', // Mapped to soft_delete_sandbox
                nonce: mtsData.nonce,
                id: id
            },
            success: function (response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    card.slideUp(300, function () {
                        $(this).remove();
                        // Update counts logic could go here, or just reload if empty
                        if ($('#sandbox-grid-active .sandbox-card').length === 0) location.reload();
                    });
                } else {
                    showToast(response.data.message, 'error');
                    btn.prop('disabled', false);
                    btn.find('.dashicons').attr('class', originalIcon);
                }
            },
            error: function () {
                showToast('請求失敗', 'error');
                btn.prop('disabled', false);
                btn.find('.dashicons').attr('class', originalIcon);
            }
        });
    });

    // --- ACTION: RESTORE ---
    $(document).on('click', '.btn-restore', function (e) {
        e.preventDefault();
        const btn = $(this);
        const card = btn.closest('.sandbox-card');
        const id = card.data('id');

        btn.prop('disabled', true).html('<span class="dashicons dashicons-update-alt spin"></span>');

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_restore_site',
                nonce: mtsData.nonce,
                id: id
            },
            success: function (response) {
                if (response.success) {
                    showToast(response.data.message, 'success');
                    location.reload(); // Simplest way to move card back to active grid
                } else {
                    showToast(response.data.message, 'error');
                    btn.prop('disabled', false).html('<span class="dashicons dashicons-undo"></span>');
                }
            }
        });
    });


    // --- ACTION: FORCE DELETE (Preview -> Modal -> Delete) ---
    let targetDeleteId = null;
    let targetDeleteCard = null;

    // 1. Click Force Delete -> Preview
    $(document).on('click', '.btn-force-delete', function (e) {
        e.preventDefault();
        const btn = $(this);
        const card = btn.closest('.sandbox-card');
        const id = card.data('id');

        targetDeleteId = id;
        targetDeleteCard = card;

        // Loading State
        const originalIcon = btn.find('.dashicons').attr('class');
        btn.find('.dashicons').attr('class', 'dashicons dashicons-update-alt spin');
        btn.prop('disabled', true);

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_preview_delete_site',
                nonce: mtsData.nonce,
                id: id
            },
            success: function (response) {
                // Reset Button
                btn.find('.dashicons').attr('class', originalIcon);
                btn.prop('disabled', false);

                if (response.success) {
                    const data = response.data;

                    // Populate Modal
                    $('#mts-modal-sandbox-name').text(data.sandbox_name);
                    $('#mts-modal-table-count').text(data.table_count);
                    $('#mts-modal-file-path').text(data.file_path);

                    // Table List
                    const listContainer = $('#mts-modal-table-list');
                    listContainer.empty();
                    if (data.table_list && data.table_list.length > 0) {
                        data.table_list.forEach(table => {
                            listContainer.append('<div>' + table + '</div>');
                        });
                        // Update prefix display
                        if (data.table_list[0]) {
                            const parts = data.table_list[0].split('_');
                            if (parts.length >= 3) {
                                $('#mts-modal-db-prefix').text(parts[0] + '_' + parts[1] + '_');
                            } else {
                                $('#mts-modal-db-prefix').text('Unknown');
                            }
                        }
                    } else {
                        listContainer.append('<div>(無資料表)</div>');
                        $('#mts-modal-db-prefix').text('None');
                    }

                    // Show Modal
                    $('#mts-confirm-modal').fadeIn(200);
                } else {
                    showMessage(response.data.message || '預覽失敗', 'error');
                }
            },
            error: function () {
                btn.find('.dashicons').attr('class', originalIcon);
                btn.prop('disabled', false);
                showMessage('連線失敗 (Preview Failed)', 'error');
            }
        });
    });

    // --- DIAGNOSTICS (Health Check) ---
    $('#mts-diagnose-btn').on('click', function (e) {
        e.preventDefault();
        const btn = $(this);
        const originalText = btn.html();

        btn.prop('disabled', true).html('<span class="dashicons dashicons-update-alt spin"></span> 診斷中...');

        const cards = $('.sandbox-card');
        let completed = 0;
        let errorsFound = 0;

        // Reset previous markings
        cards.removeClass('corrupted-site warning-site');
        cards.find('.status-badge').css('background-color', '');

        if (cards.length === 0) {
            btn.prop('disabled', false).html(originalText);
            showToast('沒有發現任何沙箱', 'warning');
            return;
        }

        cards.each(function () {
            const card = $(this);
            const id = card.data('id');
            const statusBadge = card.find('.status-badge');
            // const originalColor = statusBadge.css('background-color');

            $.ajax({
                url: mtsData.ajax_url,
                type: 'POST',
                data: {
                    action: 'mts_diagnose_site',
                    nonce: mtsData.nonce,
                    id: id
                },
                success: function (response) {
                    if (response.success) {
                        const data = response.data;
                        if (data.status === 'error') {
                            card.addClass('corrupted-site');
                            statusBadge.css('background-color', '#ef4444').text('Corrupted');
                            errorsFound++;
                            console.error(`[MTS] Site ${id} Error:`, data.issues);
                        } else if (data.status === 'warning') {
                            card.addClass('warning-site');
                            statusBadge.css('background-color', '#f59e0b').text('Warning');
                            errorsFound++;
                            console.warn(`[MTS] Site ${id} Warning:`, data.issues);
                        } else {
                            // Healthy
                            // Optional: Add a checkmark animation
                        }
                    }
                },
                complete: function () {
                    completed++;
                    if (completed >= cards.length) {
                        btn.prop('disabled', false).html(originalText);
                        if (errorsFound > 0) {
                            showToast(`診斷完成：發現 ${errorsFound} 個異常沙箱`, 'error');
                        } else {
                            showToast('診斷完成：所有系統運作正常！', 'success');
                        }
                    }
                }
            });
        });
    });

    // 2. Modal Actions
    // Close
    $('.close-modal').on('click', function () {
        $('#mts-confirm-modal').fadeOut(200);
    });

    // Toggle List
    $('#mts-toggle-table-list').on('click', function (e) {
        e.preventDefault();
        $('#mts-modal-table-list').slideToggle();
    });

    // 3. Confirm Force Delete (Real Destructive Action)
    $('#mts-confirm-delete-btn').on('click', function () {
        const btn = $(this);
        if (!targetDeleteId) return;

        const originalText = btn.text();
        btn.prop('disabled', true).text('刪除中...');

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_force_delete_site', // New Endpoint
                nonce: mtsData.nonce,
                id: targetDeleteId
            },
            success: function (response) {
                if (response.success) {
                    // Success UI
                    $('#mts-confirm-modal').fadeOut(200);
                    if (targetDeleteCard) {
                        targetDeleteCard.slideUp(300, function () {
                            $(this).remove();
                            if ($('#sandbox-grid-trash .sandbox-card').length === 0) location.reload();
                        });
                    }
                    showMessage(response.data.message, 'success');
                } else {
                    showMessage(response.data.message, 'error');
                }
                // Reset Modal Button
                btn.prop('disabled', false).text(originalText);
            },
            error: function () {
                showMessage('刪除請求失敗', 'error');
                btn.prop('disabled', false).text(originalText);
            }
        });
    });

    // Magic Login
    $(document).on('click', '.btn-magic-login', function (e) {
        e.preventDefault();
        const btn = $(this);
        const card = btn.closest('.sandbox-card');
        const id = card.data('id');

        // Add loading effect
        const originalIcon = btn.find('.dashicons').attr('class');
        btn.find('.dashicons').attr('class', 'dashicons dashicons-update-alt spin');

        $.ajax({
            url: mtsData.ajax_url,
            type: 'POST',
            data: {
                action: 'mts_get_magic_link',
                id: id,
                nonce: mtsData.nonce
            },
            success: function (response) {
                btn.find('.dashicons').attr('class', originalIcon);
                if (response.success) {
                    // Open in new tab
                    window.open(response.data.url, '_blank');
                    showToast('🚀 Magic Login Link 開啟中...<br><small>(安全提示：此連結將在 5 分鐘後失效)</small>', 'success');
                } else {
                    showToast(response.data.message || 'Login failed', 'error');
                }
            },
            error: function () {
                btn.find('.dashicons').attr('class', originalIcon);
                showToast('Request failed', 'error');
            }
        });
    });

    // Copy URL
    $(document).on('click', '.btn-copy-url', function (e) {
        e.preventDefault();
        const btn = $(this);
        const url = btn.data('url');
        const icon = btn.find('.dashicons');
        const originalIconClass = icon.attr('class');

        if (!navigator.clipboard) {
            showToast('瀏覽器不支援自動複製，請手動複製', 'error');
            return;
        }

        navigator.clipboard.writeText(url).then(function () {
            showToast('已複製連結！', 'success');
            icon.attr('class', 'dashicons dashicons-yes');
            setTimeout(() => {
                icon.attr('class', originalIconClass);
            }, 2000);
        }).catch(function (err) {
            console.error('Copy failed', err);
            showToast('複製失敗', 'error');
        });
    });

    // Sortable
    if (grid.length && $.isFunction(grid.sortable)) {
        grid.sortable({
            handle: '.card-footer',
            stop: function (event, ui) {
                const newOrder = [];
                grid.find('.sandbox-card').each(function () { newOrder.push($(this).data('id')); });

                $.ajax({
                    url: mtsData.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'mts_save_order',
                        nonce: mtsData.nonce,
                        order: newOrder
                    }
                });
            }
        });
    }
});
